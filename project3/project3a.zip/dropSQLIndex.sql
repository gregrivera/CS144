DROP INDEX userAdv ON Items;
DROP INDEX catBids ON Bids;
