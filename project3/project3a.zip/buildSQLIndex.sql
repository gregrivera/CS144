CREATE INDEX userAdv ON Items
(Buy_Price, UserID, Ends);

CREATE INDEX catBids  ON Bids
(UserID);


